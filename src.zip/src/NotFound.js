import React from 'react'

const NotFound = () => {
  return (
    <div className='PageNotFound'>NotFound</div>
  )
}

export default NotFound