import React from 'react';
import Modal from './ModalGrocery/Modal';

const CartSlider = () => {
  return (
    <>
    {/* <Modal /> */}
    
</>
  )
}

export default CartSlider;